import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class MainController {

    @FXML private GridPane puzzleGrid;
    @FXML private Button btnNuevo;
    @FXML private Label lblEstado;

    private static final int TAM_PIEZA = 150;
    private static final int COLUMNAS  = 3;
    private static final int FILAS     = 3;

    private File       imagenSeleccionada;
    private Image      imagenOriginal;
    private PuzzleGame juego;

    private int        posicionSeleccionada = -1;
    private StackPane  celdaSeleccionada    = null;

     @FXML
    public void initialize() {
        dibujarTableroVacio();
    }

    private void dibujarTableroVacio() {
        puzzleGrid.getChildren().clear();
        posicionSeleccionada = -1;
        celdaSeleccionada    = null;

        for (int fila = 0; fila < FILAS; fila++) {
            for (int col = 0; col < COLUMNAS; col++) {
                StackPane celda = new StackPane();
                celda.setPrefSize(TAM_PIEZA, TAM_PIEZA);

                Rectangle fondo = new Rectangle(TAM_PIEZA, TAM_PIEZA);
                fondo.setFill(Color.web("#45475a"));
                fondo.setArcWidth(6);
                fondo.setArcHeight(6);

                celda.getChildren().add(fondo);
                puzzleGrid.add(celda, col, fila);
            }
        }
    }

    @FXML
    private void seleccionarImagen() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Selecciona una imagen");
        chooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );

        Stage stage = (Stage) puzzleGrid.getScene().getWindow();
        File archivo = chooser.showOpenDialog(stage);

         if (archivo != null) {
            imagenSeleccionada = archivo;
            imagenOriginal     = new Image(archivo.toURI().toString(),
                                           TAM_PIEZA * COLUMNAS,
                                           TAM_PIEZA * FILAS,
                                           false, true);
            lblEstado.setText("Imagen cargada: " + archivo.getName());
            btnNuevo.setDisable(false);
        }
    }

    @FXML
    private void nuevoJuego() {
        juego = new PuzzleGame();
        juego.mezclar();
        dibujarTableroConImagen();
        lblEstado.setText("Clic en una pieza para seleccionarla, luego clic en el destino");
    }

     private void dibujarTableroConImagen() {
        puzzleGrid.getChildren().clear();
        posicionSeleccionada = -1;
        celdaSeleccionada    = null;

        WritableImage[] piezas = cortarImagen(imagenOriginal);

        for (int fila = 0; fila < FILAS; fila++) {
            for (int col = 0; col < COLUMNAS; col++) {
                int posicion    = fila * COLUMNAS + col;
                int indicePieza = juego.getPiezaEn(posicion);

                ImageView vista = new ImageView(piezas[indicePieza]);
                vista.setFitWidth(TAM_PIEZA);
                vista.setFitHeight(TAM_PIEZA);

                StackPane celda = new StackPane(vista);
                celda.setPrefSize(TAM_PIEZA, TAM_PIEZA);
                celda.setStyle("-fx-border-color: #1e1e2e; -fx-border-width: 2;");

                final int posActual = posicion;
                celda.setOnMouseClicked(e -> manejarClic(posActual, celda));

                puzzleGrid.add(celda, col, fila);
            }
        }
    }

    private WritableImage[] cortarImagen(Image imagen) {
        WritableImage[] piezas = new WritableImage[FILAS * COLUMNAS];
        int anchoImg = (int) imagen.getWidth()  / COLUMNAS;
        int altoImg  = (int) imagen.getHeight() / FILAS;

        for (int fila = 0; fila < FILAS; fila++) {
            for (int col = 0; col < COLUMNAS; col++) {
                WritableImage pieza = new WritableImage(
                    imagen.getPixelReader(),
                    col * anchoImg,
                    fila * altoImg,
                    anchoImg,
                    altoImg
                );
                piezas[fila * COLUMNAS + col] = pieza;
            }
        }
        return piezas;
    }

    private void manejarClic(int posicion, StackPane celda) {
        if (posicionSeleccionada == -1) {
            posicionSeleccionada = posicion;
            celdaSeleccionada    = celda;
            celda.setStyle("-fx-border-color: #7c3aed; -fx-border-width: 3;");
        } else {
            juego.moverPieza(posicionSeleccionada, posicion);
            dibujarTableroConImagen();

            if (juego.estaResuelto()) {
                mostrarVictoria();
            }
        }
    }

    private void mostrarVictoria() {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("¡Felicidades!");
        alerta.setHeaderText("¡Resolviste el rompecabezas!");
        alerta.setContentText("¡Excelente trabajo!");
        alerta.showAndWait();
        lblEstado.setText("¡Ganaste! Selecciona una imagen para jugar de nuevo.");
    }
}






    