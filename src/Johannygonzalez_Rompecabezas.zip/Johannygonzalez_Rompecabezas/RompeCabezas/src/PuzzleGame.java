import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PuzzleGame {
    private int[] tablero;         // posición actual de cada pieza
    private int[] solucion;        // orden correcto [0,1,2,3,4,5,6,7,8]
    private static final int TOTAL = 9;

     public PuzzleGame() {
        tablero  = new int[TOTAL];
        solucion = new int[TOTAL];
        for (int i = 0; i < TOTAL; i++) {
            solucion[i] = i;
            tablero[i]  = i;
        }
    }

    public void mezclar() {
        List<Integer> lista = new ArrayList<>();
        for (int i = 0; i < TOTAL; i++) lista.add(i);
        Collections.shuffle(lista);
        for (int i = 0; i < TOTAL; i++) tablero[i] = lista.get(i);
    }

    public void moverPieza(int posOrigen, int posDestino) {
        int temp = tablero[posOrigen];
        tablero[posOrigen] = tablero[posDestino];
        tablero[posDestino] = temp;
    }

    public boolean estaResuelto() {
        for (int i = 0; i < TOTAL; i++) {
            if (tablero[i] != solucion[i]) return false;
        }
        return true;
    }

    public int getPiezaEn(int posicion) {
        return tablero[posicion];
    }

    public int[] getTablero() {
        return tablero;
    }
}

