# JohannyGonzalez_Rompecabezas

## 1. Descripción del proyecto
Rompecabezas es un juego interactivo desarrollado en Java con JavaFX, donde el 
jugador elige una imagen desde su computadora y el sistema la divide 
automáticamente en 9 piezas iguales organizadas en una cuadrícula de 3x3. 
Las piezas son mezcladas aleatoriamente y el objetivo es devolverlas a su 
posición original intercambiándolas con clics del ratón.

**Reglas del juego:**
- Haz clic en una pieza para seleccionarla (se resalta en morado).
- Haz clic en otra pieza para intercambiar sus posiciones.
- Si haces clic dos veces en la misma pieza, la selección se cancela.
- El juego termina cuando todas las piezas están en el orden correcto.
- Al ganar, se muestra la cantidad de movimientos que tomaste.

---

## 2. Funcionalidades implementadas
- ✅ Selección de imagen desde el sistema de archivos (.png, .jpg, .jpeg)
- ✅ División automática de la imagen en 9 piezas iguales (cuadrícula 3x3)
- ✅ Mezcla aleatoria de piezas al iniciar cada partida
- ✅ Intercambio de piezas mediante clics del ratón
- ✅ Resaltado visual de la pieza seleccionada
- ✅ Contador de movimientos en pantalla
- ✅ Detección automática de victoria al completar el rompecabezas
- ✅ Validación de imagen inválida o dañada
- ✅ Validación si se intenta jugar sin seleccionar imagen
- ⬜ Temporizador (pendiente)
- ⬜ Selección de dificultad (pendiente)

---

## 3. Requisitos previos
- Java JDK 17 o superior
- Maven 3.8 o superior
- JavaFX 21 (se descarga automáticamente con Maven)
- IDE recomendado: IntelliJ IDEA

---

## 4. Cómo ejecutar el proyecto

### Opción 1 — Desde la terminal con Maven
```bash
# Clonar el repositorio
git clone https://github.com/JohannyGonzalez/JohannyGonzalez_Rompecabezas.git

# Entrar a la carpeta del proyecto
cd JohannyGonzalez_Rompecabezas

# Ejecutar el proyecto
mvn javafx:run
```
### Opción 2 — Desde IntelliJ IDEA
1. Abrir IntelliJ IDEA
2. Ir a **File > Open** y seleccionar la carpeta del proyecto
3. Esperar a que Maven descargue las dependencias automáticamente
4. Ubicar el archivo `App.java` y presionar el botón **Run**

---

## 5. Estructura del proyecto
JohannyGonzalez_Rompecabezas/
├── src/
│   └── main/
│       ├── java/
│       │   ├── App.java               # Punto de entrada de la aplicación JavaFX
│       │   ├── MainController.java    # Controlador de la interfaz y eventos del usuario
│       │   └── PuzzleGame.java        # Lógica del juego: tablero, mezcla y validación
│       └── resources/
│           └── main.fxml              # Diseño de la interfaz gráfica en FXML
├── pom.xml                            # Configuración de Maven y dependencias JavaFX
└── README.md                          # Documentación del proyecto

---

## 6. Decisiones de diseño
- **Separación de responsabilidades:** La lógica del juego se mantuvo en 
  `PuzzleGame.java` separada de la interfaz en `MainController.java`, siguiendo 
  el patrón MVC para un código más organizado y fácil de mantener.
- **Corte de imagen en memoria:** Se utilizó `WritableImage` junto a `PixelReader` 
  de JavaFX para dividir la imagen en 9 piezas directamente en memoria, sin 
  necesidad de guardar archivos temporales en disco.
- **Mezcla aleatoria real:** Se usó `Collections.shuffle()` para garantizar que 
  las piezas siempre queden en un orden diferente al inicio de cada partida.
- **Intercambio por doble clic:** El jugador selecciona la pieza origen con el 
  primer clic y la pieza destino con el segundo, resaltando visualmente la 
  selección activa en color morado para mayor claridad.
- **FXML para la interfaz:** Se utilizó FXML para separar completamente el diseño 
  visual del código Java, lo que facilita modificar la interfaz sin tocar la lógica.
- **Validaciones con Alert:** Se implementaron alertas de error para guiar al 
  usuario en caso de seleccionar una imagen inválida o intentar jugar sin 
  haber cargado una imagen.

---

## 7. Autor
**Nombre:** Johanny Gonzalez  
**Fecha de entrega:** 12 Abril 2026